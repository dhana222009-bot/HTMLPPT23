// JavaScript: make the example button interactive.
document.addEventListener("DOMContentLoaded", function () {
  const nameInput = document.getElementById("studentName");
  const greetButton = document.getElementById("greetButton");
  const greeting = document.getElementById("greeting");

  greetButton.addEventListener("click", function () {
    const name = nameInput.value.trim();

    if (name === "") {
      greeting.textContent = "Please enter your name first.";
      nameInput.focus();
      return;
    }

    // textContent safely displays the name as text.
    greeting.textContent = "Hello, " + name + "! Welcome to HTML learning.";
  });

  nameInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
      greetButton.click();
    }
  });
});
