HTML Learning Guide — Project Files

Files:
- index.html : page content and diagrams
- style.css  : colors, layout, responsive design
- script.js  : interactive greeting example

How to run:
1. Keep all three files in the same folder.
2. Double-click index.html to open it in your browser.
3. Scroll through the five topics.
4. At “Interactive Example”, type a name and click “Show greeting”.

No internet connection or installation is required.
